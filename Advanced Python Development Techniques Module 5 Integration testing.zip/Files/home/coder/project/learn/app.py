from flask import Flask, request, jsonify, render_template

app = Flask(__name__)

posts = []  # Correct initialization

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/posts', methods=['GET'])
def get_posts():
    return jsonify(posts), 200

@app.route('/posts', methods=['POST'])
def create_post():
    data = request.get_json()

    if not data or 'title' not in data or 'content' not in data:
        return jsonify({'error': 'Invalid data'}), 400

    new_post = {
        'id': len(posts) + 1,
        'title': data['title'],
        'content': data['content']
    }

    posts.append(new_post)

    return jsonify(new_post), 201

if __name__ == '__main__':
    app.run(debug=True)
