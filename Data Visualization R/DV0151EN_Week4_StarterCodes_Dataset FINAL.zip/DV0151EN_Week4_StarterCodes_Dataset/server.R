# server.R
library(shiny)
library(tidyverse)

adult <- read_csv("adult.csv")
names(adult) <- tolower(names(adult))

shinyServer(function(input, output) {
  
  df_country <- reactive({
    dplyr::filter(adult, native_country == input$country)
  })
  
  # Continuous: histogram or boxplot
  output$p1 <- renderPlot({
    var <- input$continuous_variable
    var_label <- if (var == "hours_per_week") "Hours per week" else "Age"
    
    if (input$graph_type == "histogram") {
      ggplot(df_country(), aes_string(x = var)) +
        geom_histogram(bins = 30) +
        labs(x = var_label, y = "Count", title = paste("Histogram of", var_label, "by income")) +
        facet_wrap(~prediction)
    } else {
      ggplot(df_country(), aes_string(x = "prediction", y = var)) +
        geom_boxplot() +
        coord_flip() +
        labs(x = "Income", y = var_label, title = paste("Boxplot of", var_label, "by income")) +
        facet_wrap(~prediction)
    }
  })
  
  # Categorical: stacked or faceted bars
  output$p2 <- renderPlot({
    cat_var <- input$categorical_variable
    cat_label <- switch(cat_var,
                        education = "Education",
                        workclass = "Workclass",
                        sex = "Sex",
                        cat_var)
    
    p <- ggplot(df_country(), aes_string(x = cat_var)) +
      labs(x = cat_label, y = "Count", title = paste("Distribution of", cat_label, "by income")) +
      theme(axis.text.x = element_text(angle = 45, hjust = 1),
            legend.position = "bottom")
    
    if (isTRUE(input$is_stacked)) {
      p + geom_bar(aes(fill = prediction), position = "stack")
    } else {
      p + geom_bar(aes_string(fill = cat_var)) + facet_wrap(~prediction)
    }
  })
  
})
